// Get the search bar element
const searchMain = document.getElementById("searchMain");

// Add event listener to the search bar
searchMain.addEventListener("click", function() {
  // Add a class to the body element to darken the page and show the search bar
  document.body.classList.add("search-bar-open");
});

// Add event listener to the body element
document.body.addEventListener("click", function(event) {
  // If the user clicks outside of the search bar, hide it
  if (event.target !== searchMain) {
    document.body.classList.remove("search-bar-open");
  }
});
